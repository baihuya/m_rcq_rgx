#!/system/bin/sh
chmod +x /data/adb/modules/m_rcq/bin/ksu_reload.sh /data/adb/modules/m_rcq/bin/rcq_xt.sh /data/adb/modules/m_rcq/bin/fix_lspd.sh
rm -rf /data/adb/modules/m_rcq/sh.zip
rm -rf /data/adb/rcqpz
chmod 755 /data/adb/m_rcq/service.sh

ceho "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "— 请选择操作："
echo "— [ 音量 加(+): 重载模块 ]"
    echo "— [ 音量 减(-): 修复 LSPosed ]"
    echo "— [ 7秒内未执行操作自动执行隐藏免解越狱 ]"
    
START_TIME=$(date +%s)
while true; do
  NOW_TIME=$(date +%s)
  timeout 1 getevent -lc 1 2>&1 | grep KEY_VOLUME > "$TMPDIR/events"

  if [ $(( NOW_TIME - START_TIME )) -gt 7 ]; then
    ui_print "— 超时未执行功能，默认执行热重启..."
    /data/adb/modules/m_rcq/bin/rcq_xt.sh
    break
  elif grep -q KEY_VOLUMEUP "$TMPDIR/events"; then
    ui_print "— 检测到音量加键 → 重载模块"
    /data/adb/modules/m_rcq/bin/ksu_reload.sh
    break
  elif grep -q KEY_VOLUMEDOWN "$TMPDIR/events"; then
    ui_print "— 检测到音量减键 → 修复 LSPosed"
     /data/adb/modules/m_rcq/bin/fix_lspd.sh    
    break
  fi
done