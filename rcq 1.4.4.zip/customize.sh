#!/system/bin/sh

ui_print ""
ui_print "热重启模块 KernelSU越狱模式专用"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 只允许 KernelSU
if [ "$KSU" != "true" ]; then
  abort "本模块**仅限 KernelSU**临时root（越狱模式）使用！\n请勿在 Magisk / APatch 等环境下安装。"
fi

ui_print "→ KernelSU v$KSU_VER ($KSU_VER_CODE) 检测通过"

echo ""
echo "修复lsp仅it版可用，过程中会热重启"
echo "后续使用请在模块页面点击左下按纽运行"
echo "本模块仅提供了一种免重启让模块加载的方式，不能保证成功。"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 释放、配置权限
echo "正在释放所需文件并配置权限"
unzip -o "$MODPATH/sh.zip" -d "/data/adb/rcqpz/" > /dev/null
chmod +x /data/adb/rcqpz/ksu_reload.sh
echo "释放完成"

echo "。。。。。。。"
rm -rf /data/adb/modules/h_reboot
rm -rf /data/local/tmp/rcq_xt.sh
rm -rf /data/local/tmp/fix_lspd.sh
rm -rf /data/local/tmp/ksu_reload.sh

echo ""

# 自动检测是否已安装模块
MODULE_PATH="/data/adb/modules"
if [ -d "$MODULE_PATH" ]; then
    ui_print "— 检测到模块已安装 → 5秒后执行重载"
    # 5秒倒计时提示
    for i in 5 4 3 2 1; do
        ui_print "→ $i 秒后开始重载..."
        sleep 1
    done
    /data/adb/rcqpz/ksu_reload.sh
    rm -rf /data/adb/rcqpz
else
    ui_print "— 未检测到模块目录 → 跳过重载，首次安装失败"
fi
