#!/system/bin/sh

check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop -n $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop -n $NAME $NEWVAL
}

restorecon /dev/__properties__/u:object_r:adbd_config_prop:s0
restorecon /dev/__properties__/u:object_r:shell_prop:s0

resetprop -w sys.boot_completed 0

resetprop -f ro.oem_unlock_supported 0
resetprop -n sys.usb.config ""
resetprop -n sys.usb.state ""
check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"

check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "ro.oem_unlock_supported" "0"
check_reset_prop "persist.sys.usb.config" "none"
check_reset_prop "persist.service.adb.enable" "0"
check_reset_prop "persist.sys.root_access" "0"
check_reset_prop "service.adb.root" "0"
check_reset_prop "ro.crypto.state" "encrypted"
check_reset_prop "ro.build.selinux" "1"
check_reset_prop "ro.config.low_ram" "false"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "sys.oem_unlock_allowed" "0"

check_reset_prop "ro.boot.selinux" "enforcing"
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"

check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"
check_reset_prop "persist.bluetooth.current.scanmode.iac" "GIAC"


mount -o remount,rw /system_ext
umount -l /system_ext/bin/horae
rm -rf /system_ext/bin/horae
mount -o remount,ro /system_ext

setenforce 1

STATUS=$(getenforce)
if [ "$STATUS" = "Permissive" ]; then
  setenforce 1
fi

resetprop -w sys.boot_completed 1
