#!/system/bin/sh
TMPDIR="/data/local/tmp"
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:$PATH
mkdir -p "$TMPDIR"
chmod 755 /data/adb/modules/m_rcq/bin/fix_lspd.sh 2>/dev/null
chmod 755 /data/adb/modules/m_rcq/service.sh 2>/dev/null

ui_print() {
  echo "$1"
}

echo "====================================="
echo "— 请根据提示完成配置"
echo "  "
echo "前提：已经安装了新版本LSP模块并安装了zygisk next模块"
echo "且已在模块UI界面完成重载KSU"
echo "教程：安装新版本LSP后需要执行初始化"
echo "  "
echo "执行初始化完成后，在KSU界面重新安装新版本LSP模块"
echo ""
echo "完成安装后，打开本模块UI界面执行重载模块"
echo "完成后即可执行修复LSP功能"
echo ""
echo "只有第一次安装新版本LSP需要这样操作"
echo "之后冷重启也是只需要执行修复lsp功能就好了"
echo "  "
echo "如果冷重启之后执行修复，显示修复失败，重新按照教程走一遍"
echo "  "
echo "老版本不需要初始化直接修复即可"
echo "  "
echo " "
echo "— [ 音量 加(+): 初始化 ]"
echo "— [ 音量 减(-): 修复LSP ]"
echo "— [ 超时30秒退出此界面]"
echo "====================================="

START_TIME=$(date +%s)
enter_second=0

while true; do
  NOW_TIME=$(date +%s)
  timeout 1 getevent -lc 1 2>&1 | grep KEY_VOLUME > "$TMPDIR/events"

  # 音量加：一级初始化（正常保留）
  if grep -q KEY_VOLUMEUP "$TMPDIR/events" && [ $enter_second -eq 0 ]; then
    ui_print "— 检测到音量加键 → 正在初始化"
    TARGET_APK="/data/adb/modules/zygisk_lsposed/manager.apk"

    if [ -f "$TARGET_APK" ]; then
      ui_print "— 找到文件，开始执行初始化..."
      pm install -r -d "$TARGET_APK" >/dev/null 2>&1

      if [ $? -eq 0 ]; then
        ui_print "— ✅ 初始化LSP管理器安装成功"
        service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "初始化成功" i32 0
      else
        ui_print "— ❌ 初始化LSP管理器安装失败"
        service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "初始化失败" i32 0
      fi
    else
      ui_print "— ❌ 未找到安装文件：$TARGET_APK"
      service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "安装包缺失" i32 0
    fi
    break
  elif grep -q KEY_VOLUMEDOWN "$TMPDIR/events" && [ $enter_second -eq 0 ]; then
    enter_second=1
    ui_print ""
    ui_print "========== LSP修复选择 =========="
    ui_print "— 音量+：卸载LSP完成修复（更好的隐藏）"
    ui_print "— 音量-： 直接修复 不卸载  （更方便）"
    ui_print "=================================="
    continue
  fi

  if [ $((NOW_TIME - START_TIME)) -ge 35 ]; then
    ui_print "— 超时30秒未操作，自动退出"
    rm -f "$TMPDIR/events"
    exit 0
  fi

  if [ $enter_second -eq 1 ]; then
    break
  fi
done

if [ $enter_second -eq 1 ]; then
  SECOND_START=$(date +%s)
  while true; do
    SECOND_NOW=$(date +%s)
    timeout 1 getevent -lc 1 2>&1 | grep KEY_VOLUME > "$TMPDIR/events"

    if grep -q KEY_VOLUMEUP "$TMPDIR/events"; then
      ui_print "— 检测到音量加 → 卸载旧LSP并修复"
      ui_print "— 正在卸载旧版 LSPosed 管理器..."
      pm uninstall -k --user 0 org.lsposed.manager >/dev/null 2>&1
      ui_print "— ✅ LSP卸载完成，开始修复"
      /data/adb/modules/m_rcq/bin/fix_lspd.sh
      echo "— 正在进行修复lsp"
      service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "修复中" i32 0
      break

    elif grep -q KEY_VOLUMEDOWN "$TMPDIR/events"; then
      ui_print "— 检测到音量减 → 修复LSP"
      /data/adb/modules/m_rcq/bin/fix_lspd.sh
      echo "— 正在进行修复lsp"
      service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "修复中" i32 0
      break
    fi

    if [ $((SECOND_NOW - SECOND_START)) -ge 10 ]; then
      ui_print "— 二级菜单超时，自动退出"
      break
    fi
  done
fi

rm -f "$TMPDIR/events"
exit 0
