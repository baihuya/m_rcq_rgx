#!/system/bin/sh

ui_print ""
ui_print "热重启模块 KernelSU越狱模式专用"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 只允许 KernelSU
if [ "$KSU" != "true" ]; then
  abort "本模块**仅限 KernelSU**临时root（越狱模式）使用！\n请勿在 Magisk / APatch 等环境下安装。"
fi

ui_print "→ KernelSU v$KSU_VER ($KSU_VER_CODE) 检测通过"

ui_print "→ 正在校验模块完整性..."
FAIL=0
if [ -f "$MODPATH/.rcq_d" ]; then
    HEX_DATA=$(cat "$MODPATH/.rcq_d" 2>/dev/null)
    KEY="rcq210_baihu_2026"
    KEYLEN=${#KEY}
    TMPF=$(mktemp 2>/dev/null || echo /data/local/tmp/.rcq_v)
    i=0
    while [ $i -lt ${#HEX_DATA} ]; do
        HEXBYTE="${HEX_DATA:$i:2}"
        DEC=$((16#$HEXBYTE))
        KIDX=$(( (i / 2) % KEYLEN ))
        KCHAR="${KEY:$KIDX:1}"
        KORD=$(printf '%d' "'$KCHAR" 2>/dev/null)
        X=$((DEC ^ KORD))
        printf "\\$(printf '%03o' $X)" >> "$TMPF" 2>/dev/null
        i=$((i + 2))
    done
    while IFS= read -r line; do
        HASH=$(echo "$line" | cut -d' ' -f1)
        FILE=$(echo "$line" | sed 's/^[^ ]*  //')
        [ -z "$FILE" ] && continue
        if [ -f "$MODPATH/$FILE" ]; then
            ACTUAL=$(sha256sum "$MODPATH/$FILE" 2>/dev/null | cut -d' ' -f1)
            if [ "$ACTUAL" != "$HASH" ]; then
                ui_print "  ! 文件已被篡改: $FILE"
                FAIL=1
            fi
        else
            ui_print "  ! 文件缺失: $FILE"
            FAIL=1
        fi
    done < "$TMPF"
    rm -f "$TMPF"
else
    ui_print "  ! 未找到校验数据"
    FAIL=1
fi
if [ $FAIL -eq 1 ]; then
    abort "模块完整性校验失败！文件可能被篡改或损坏，安装终止。"
fi
ui_print "→ 完整性校验通过"
rm rf /data/adb/modules/m_rcq/.rcq_d

echo ""
echo "热重启模块 2.1.0    是小白狐呀"
echo "后续使用请在模块页面点击左下按纽运行"
echo "本模块仅提供了一种免重启让模块加载的方式，不能保证成功。"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 释放、配置权限
echo "正在释放所需文件并配置权限"
unzip -o "$MODPATH/c1.zip" -d "/data/adb/rcqpz/" > /dev/null
chmod +x /data/adb/rcqpz/jz.sh
echo "释放1完成"

# 自动检测是否已安装模块
MODULE_PATH="/data/adb"
if [ -d "$MODULE_PATH" ]; then
    ui_print "— 检测到KSU环境 → 3秒后执行重载"
    # 5秒倒计时提示
    for i in 3 2 1; do
        ui_print "→ $i 秒后开始重载..."
        sleep 1
    done
    /data/adb/rcqpz/jz.sh
    rm -rf /data/adb/rcqpz
    rm rf /data/adb/modules/m_rcq/.rcq_d
else
    ui_print "— 未检测到模块目录 → 跳过重载，首次安装失败"
fi

rm -f "$MODPATH/.rcq_d"
ui_print "→ 校验数据已清理"
