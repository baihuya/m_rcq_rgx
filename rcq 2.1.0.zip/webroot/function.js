const navItems = document.querySelectorAll('.nav-item');
navItems.forEach(item => {
    item.addEventListener('click', function() {
        const tab = this.dataset.tab;
        if (tab === 'home') {
            window.location.replace('index.html');
        }
    });
});

const GAME_LIST = [
    { name: '和平精英', pkg: 'com.tencent.tmgp.pubgmhd' },
    { name: '三角洲', pkg: 'com.tencent.tmgp.dfm' },
    { name: '无畏契约', pkg: 'com.tencent.tmgp.codev' },
    { name: '王者荣耀', pkg: 'com.tencent.tmgp.sgame' },
    { name: '暗区突围', pkg: 'com.tencent.mf.uam' },
    { name: 'Folk', pkg: 'me.yuki.folk' }
];

const RKP_FIX_URL = 'https://raw.githubusercontent.com/baihuya/m_rcq_rgx/refs/heads/main/bin/一键激活RKP为正常状态.sh';

let currentModal = null;

function closeModal() {
    if (currentModal) {
        currentModal.remove();
        currentModal = null;
    }
}

function createModal(contentHtml) {
    closeModal();
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop show';
    backdrop.innerHTML = `
        <div class="modal-box sub-modal-box">
            ${contentHtml}
        </div>
    `;
    backdrop.addEventListener('click', e => {
        if (e.target === backdrop) closeModal();
    });
    document.body.appendChild(backdrop);
    currentModal = backdrop;
    return backdrop;
}

function showResult(success, title, desc) {
    const iconClass = success ? 'fa-check text-ksuGreen' : 'fa-times text-ksuRed';
    const bgClass = success ? 'bg-ksuGreen/10' : 'bg-ksuRed/10';
    createModal(`
        <div class="flex flex-col items-center text-center">
            <div class="w-16 h-16 rounded-full flex items-center justify-center mb-4 ${bgClass}">
                <i class="fa ${iconClass} text-2xl"></i>
            </div>
            <h3 class="text-lg font-semibold text-ksuTextMain mb-2">${title}</h3>
            <p class="text-sm text-ksuTextSub mb-6">${desc}</p>
            <button class="w-full py-3.5 bg-ksuBlue text-white rounded-xl font-semibold text-base active:opacity-90" onclick="closeModal()">
                确定
            </button>
        </div>
    `);
}

function fixRkpRed() {
    const tempPath = '/data/local/tmp/rkp_fix_tool';
    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">正在下载修复文件...</p>
        </div>
    `);

    const xhr = new XMLHttpRequest();
    xhr.open('GET', RKP_FIX_URL, true);
    xhr.responseType = 'blob';

    xhr.onload = async function() {
        if (xhr.status !== 200) {
            showResult(false, '下载失败', `修复文件下载失败，状态码：${xhr.status}`);
            return;
        }
        try {
            const blob = xhr.response;
            const arrayBuffer = await blob.arrayBuffer();
            const bytes = new Uint8Array(arrayBuffer);
            const binStr = Array.from(bytes).map(b => String.fromCharCode(b)).join('');
            const base64 = btoa(binStr);
            await ksu.exec(`echo '${base64}' | base64 -d > ${tempPath}`);
            await ksu.exec(`chmod 755 ${tempPath}`);

            const statusText = document.querySelector('.modal-box p');
            if (statusText) statusText.textContent = '正在执行修复...';

            const execRes = await ksu.exec(`sh ${tempPath}`);
            if (execRes.errno === 0) {
                showResult(true, '修复指令已下发', 'RKP修复操作已执行');
                setTimeout(() => ksu.exec(`rm -f ${tempPath}`), 30000);
            } else {
                showResult(false, '修复指令已下发', 'RKP修复操作已执行，请稍等......');
                ksu.exec(`rm -f ${tempPath}`);
            }
        } catch (e) {
            showResult(false, '可能是模块报错？', e.message || '文件写入异常');
            ksu.exec(`rm -f ${tempPath}`);
        }
    };

    xhr.onerror = function() {
        showResult(false, '下载失败', '网络连接异常，请检查网络后重试');
    };

    xhr.send();
}

function openRecWipeNotice() {
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">风险提示</h3>
        <p class="text-sm text-ksuTextSub mb-6 text-center leading-relaxed">
            此操作会重置应用权限<br>并刷新设备标识<br><br>其他应用可能需要<br>重新打开才能正常使用
        </p>
        <button class="w-full py-3 bg-ksuRed text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); openRecWipeMenu()">
            确定执行
        </button>
        <button class="btn-secondary" onclick="closeModal()">取消</button>
    `);
}

function openRecWipeMenu() {
    let listHtml = '<h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">选择游戏</h3><div class="space-y-2">';
    GAME_LIST.forEach((game, index) => {
        listHtml += `
            <button class="w-full py-3 bg-[#F8F8FC] rounded-xl text-sm font-medium text-ksuTextMain active:bg-[#EFEFF4] transition" onclick="closeModal(); showRecCloneMenu(${index})">
                ${game.name}
            </button>
        `;
    });
    listHtml += '</div><button class="btn-secondary mt-4" onclick="closeModal()">返回</button>';
    createModal(listHtml);
}

function showRecCloneMenu(index) {
    const game = GAME_LIST[index];
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">${game.name}</h3>
        <button class="w-full py-3 bg-ksuBlue text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); executeRecWipe(${index}, false)">
            主应用
        </button>
        <button class="w-full py-3 bg-ksuBlue text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); executeRecWipe(${index}, true)">
            分身应用
        </button>
        <button class="btn-secondary" onclick="closeModal()">返回</button>
    `);
}

async function executeRecWipe(index, isClone) {
    const game = GAME_LIST[index];
    const pkg = game.pkg;
    const name = game.name;
    const dataBase = isClone ? `/data/user/999/${pkg}` : `/data/data/${pkg}`;

    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">正在执行双清...</p>
        </div>
    `);

    let steps;
    if (isClone) {
        steps = [
            `am force-stop ${pkg} 2>/dev/null`,
            `rm -rf /data/user/999/${pkg}/* /data/user/999/${pkg}/.* 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg}.xml 2>/dev/null`,
            `rm -rf ${dataBase}/files/ano_tmp 2>/dev/null`,
            `rm -rf /data/system/users/0/android_id.xml 2>/dev/null`,
            `rm -rf /data/system/advertising_id 2>/dev/null`,
            `rm -rf /data/system/oaid 2>/dev/null`,
            `rm -rf /sdcard/Android/data/${pkg} 2>/dev/null`,
            `rm -rf /sdcard/Android/obb/${pkg} 2>/dev/null`,
            `pm reset-permissions ${pkg} 2>/dev/null`,
            `pm revoke ${pkg} android.permission.READ_PHONE_STATE 2>/dev/null`,
            `pm revoke ${pkg} android.permission.QUERY_ALL_PACKAGES 2>/dev/null`
        ].join(" && ");
    } else {
        steps = [
            `am force-stop ${pkg} 2>/dev/null`,
            `pm clear ${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg}.xml 2>/dev/null`,
            `rm -rf ${dataBase}/files/ano_tmp 2>/dev/null`,
            `rm -rf /data/system/users/0/android_id.xml 2>/dev/null`,
            `rm -rf /data/system/advertising_id 2>/dev/null`,
            `rm -rf /data/system/oaid 2>/dev/null`,
            `rm -rf /sdcard/Android/data/${pkg} 2>/dev/null`,
            `rm -rf /sdcard/Android/obb/${pkg} 2>/dev/null`,
            `pm reset-permissions ${pkg} 2>/dev/null`,
            `pm revoke ${pkg} android.permission.READ_PHONE_STATE 2>/dev/null`,
            `pm revoke ${pkg} android.permission.QUERY_ALL_PACKAGES 2>/dev/null`
        ].join(" && ");
    }

    try {
        await ksu.exec(steps);
        setTimeout(() => {
            const label = isClone ? `${name}（分身）` : `${name}（主应用）`;
            showResult(true, '双清完成', `${label} 数据、标识、权限已全部重置`);
        }, 800);
    } catch (e) {
        showResult(false, '执行失败', e.message || '权限不足或应用不存在');
    }
}
async function randomizeDeviceId() {
    const script = '/data/adb/modules/m_rcq/bin/randomize_id.sh';
    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">正在随机化设备标识...</p>
        </div>
    `);
    try {
        await ksu.exec(`chmod 755 ${script}`);
        await ksu.exec(`sh -c 'nohup sh ${script} > /dev/null 2>&1 &'`);
        await new Promise(r => setTimeout(r, 2000));
        showResult(true, '随机化完成', '设备标识已随机化');
    } catch (e) {
        showResult(false, '执行失败', e.message || '未知错误');
    }
}

async function toggleKillMt() {
    const flagFile = '/data/adb/modules/m_rcq/.kill_mt_on';
    const script = '/data/adb/modules/m_rcq/bin/kill_mt.sh';
    let isOn = false;
    try {
        const statusRes = await ksu.exec(`[ -f ${flagFile} ]`);
        isOn = statusRes.errno === 0;
    } catch (e) {
        isOn = false;
    }
    const statusText = isOn ? '<span style="color:#22c55e">运行中</span>' : '<span style="color:#9ca3af"> </span>';
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-2 text-center">杀死MT进程</h3>
        <p class="text-sm text-ksuTextSub mb-4 text-center"> ${statusText}</p>
        <p class="text-xs text-ksuTextSub mb-4 text-center">三角洲运行时自动杀死MT管理器及相关进程</p>
        <button class="w-full py-3 bg-ksuBlue text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); doKillMt('start')">
            开启
        </button>
        <button class="w-full py-3 bg-[#F8F8FC] text-ksuTextMain rounded-xl font-semibold text-sm mb-3 active:bg-[#EFEFF4]" onclick="closeModal(); doKillMt('stop')">
            关闭
        </button>
        <button class="btn-secondary" onclick="closeModal()">返回</button>
    `);
}

async function doKillMt(action) {
    const flagFile = '/data/adb/modules/m_rcq/.kill_mt_on';
    const script = '/data/adb/modules/m_rcq/bin/kill_mt.sh';
    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">${action === 'start' ? '正在开启...' : '正在关闭...'}</p>
        </div>
    `);
    try {
        await ksu.exec(`chmod 755 ${script}`);
        if (action === 'start') {
            await ksu.exec(`sh ${script} start`);
            await new Promise(r => setTimeout(r, 500));
            showResult(true, '已开启', '三角洲运行时将自动杀死MT进程');
        } else {
            await ksu.exec(`sh ${script} stop`);
            showResult(true, '已关闭', '杀死MT进程功能已关闭');
        }
    } catch (e) {
        showResult(false, action === 'start' ? '开启失败' : '关闭失败', e.message || '执行异常');
    }
}
