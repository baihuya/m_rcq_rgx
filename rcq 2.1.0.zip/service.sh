#!/system/bin/sh
check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -z "$VALUE" ] || [ "$VALUE" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

force_reset_prop() {
  resetprop -n "$1" "$2" 2>/dev/null
}

contains_reset_prop() {
  local NAME="$1"
  local CONTAINS="$2"
  local NEWVAL="$3"
  [[ "$(resetprop "$NAME" 2>/dev/null)" = *"$CONTAINS"* ]] && resetprop -n "$NAME" "$NEWVAL"
}

echo 2 > /proc/sys/kernel/kptr_restrict
echo 1 > /proc/sys/kernel/dmesg_restrict
echo 0 > /proc/sys/fs/suid_dumpable
echo 0 > /proc/sys/kernel/core_pattern
echo 2 > /proc/sys/kernel/perf_event_paranoid

chmod 777 /data/adb/modules/m_rcq/I_am_taffy
/data/adb/modules/m_rcq/I_am_taffy

resetprop -w sys.boot_completed 0

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"

check_reset_prop "vendor.boot.flash.locked" "1"
check_reset_prop "vendor.boot.veritymode" "enforcing"
check_reset_prop "ro.vendor.boot.flash.locked" "1"
check_reset_prop "ro.vendor.boot.veritymode" "enforcing"
check_reset_prop "vendor.secureboot.lockstate" "locked"
check_reset_prop "vendor.boot.secureboot" "1"

check_reset_prop "odm.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.odm.boot.vbmeta.device_state" "locked"
check_reset_prop "odm.boot.verifiedbootstate" "green"
check_reset_prop "odm.boot.flash.locked" "1"
check_reset_prop "odm.boot.veritymode" "enforcing"

check_reset_prop "ro.secureboot.enabled" "1"
check_reset_prop "ro.boot.vbmeta.bootloader_state" "locked"
check_reset_prop "ro.boot.secboot.enabled" "1"
check_reset_prop "ro.boot.frp.lock" "1"
check_reset_prop "ro.vendor.boot.secureboot" "1"
check_reset_prop "persist.sys.secboot.state" "1"
check_reset_prop "ro.boot.vbmeta.rollback_index" "0"
check_reset_prop "ro.boot.vbmeta.device_locked" "1"
check_reset_prop "ro.secureboot.devicelock" "1"

check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"

check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

check_reset_prop "ro.boot.bootloader" "locked"
check_reset_prop "ro.boot.locked" "1"
check_reset_prop "ro.build.bootloader" "locked"

check_reset_prop "ro.boot.avb_version" "1.0"
check_reset_prop "ro.boot.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_version" "1.0"
check_reset_prop "ro.boot.vbmeta.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_status" "ok"
check_reset_prop "ro.boot.vbmeta.status" "ok"
check_reset_prop "ro.boot.vbmeta.hash_alg" "sha256"
check_reset_prop "ro.boot.vbmeta.invalidate_on_error" "yes"

check_reset_prop "ro.tee.status" "ok"
check_reset_prop "vendor.tee.status" "ok"
check_reset_prop "sys.tee.ready" "1"
check_reset_prop "persist.tee.ready" "1"

check_reset_prop "ro.soter.available" "1"
check_reset_prop "persist.soter.available" "1"
check_reset_prop "vendor.soter.available" "1"
check_reset_prop "ro.soter.supported" "1"
check_reset_prop "persist.soter.supported" "1"

check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"

force_reset_prop "ro.is_ever_orange" "0"

check_reset_prop "ro.crypto.state" "encrypted"
check_reset_prop "init.svc.adbd" "stopped"
check_reset_prop "init.svc.flash_recovery" "stopped"
check_reset_prop "net.tethering.noprovisioning" "true"

for prefix in bootimage odm odm_dlkm oem product system system_ext vendor vendor_dlkm; do
    check_reset_prop "ro.${prefix}.build.type" "user"
    check_reset_prop "ro.${prefix}.build.tags" "release-keys"
    check_reset_prop "ro.${prefix}.keys" "release-keys"
done

contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.mode" "recovery" "unknown"
contains_reset_prop "vendor.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.mode" "recovery" "unknown"

settings delete global hidden_api_policy 2>/dev/null
settings delete global hidden_api_policy_pre_p_apps 2>/dev/null
settings delete global hidden_api_policy_p_apps 2>/dev/null
settings put global block_untrusted_touches 2 2>/dev/null
settings put system block_untrusted_touches 2 2>/dev/null
settings put secure block_untrusted_touches 2 2>/dev/null

setenforce 1
resetprop -w sys.boot_completed 1

HIDE_PROCS="magisk magiskd su ksu ksud kernelsu ksuhelper"

for proc_name in $HIDE_PROCS; do
    for pid in $(pidof "$proc_name" 2>/dev/null); do
        chmod 000 "/proc/$pid" 2>/dev/null
        if [ -d "/proc/$pid/task" ]; then
            for tid in /proc/$pid/task/*; do
                chmod 000 "$tid" 2>/dev/null
            done
        fi
    done
done

chmod 000 /proc/ksu 2>/dev/null
chmod 000 /proc/kallsyms 2>/dev/null
chmod 000 /proc/modules 2>/dev/null
chmod 000 /sys/kernel/debug 2>/dev/null
chmod 000 /sys/kernel/debug/tracing 2>/dev/null
chmod 440 /proc/cmdline 2>/dev/null
chmod 440 /proc/net/unix 2>/dev/null

[ -f /sys/fs/selinux/enforce ] && chmod 640 /sys/fs/selinux/enforce 2>/dev/null
[ -f /sys/fs/selinux/policy ] && chmod 440 /sys/fs/selinux/policy 2>/dev/null

find /vendor/bin /system/bin -name install-recovery.sh 2>/dev/null | while read -r file; do
    chmod 440 "$file" 2>/dev/null
done

chmod 750 /system/addon.d 2>/dev/null
chmod 750 /sdcard/TWRP 2>/dev/null

echo 1 > /proc/sys/kernel/randomize_va_space
echo 0 > /proc/sys/vm/oom_dump_tasks 2>/dev/null
