#!/system/bin/sh
TMPDIR="/data/local/tmp"
mkdir -p "$TMPDIR"

chmod 755 /data/adb/modules/m_rcq/bin/fix_lspd.sh

ui_print() {
  echo "$1"
}

echo "====================================="
echo "— 请根据提示完成配置"
echo "— [ 音量 加(+): 修复Lsp ]"
echo "— [ 音量 减(-): 退出模块 ]"
echo "====================================="

START_TIME=$(date +%s)
while true; do
  NOW_TIME=$(date +%s)
  timeout 1 getevent -lc 1 2>&1 | grep KEY_VOLUME > "$TMPDIR/events"

  if grep -q KEY_VOLUMEUP "$TMPDIR/events"; then
    ui_print "— 检测到音量加键 → 正在修复"
    /data/adb/modules/m_rcq/bin/fix_lspd.sh
    echo "— 正在进行修复lsp"
    service call notification 16 s16 "RCQ模块" i32 0 i32 0 s16 "修复中" i32 0
    break
  elif grep -q KEY_VOLUMEDOWN "$TMPDIR/events"; then
    ui_print "— 检测到音量减键 → 已退出模块界面"
    break
  fi
done

rm -f "$TMPDIR/events"
