#!/system/bin/sh

ui_print ""
ui_print "热重启模块 KernelSU越狱模式专用"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 只允许 KernelSU
if [ "$KSU" != "true" ]; then
  abort "本模块**仅限 KernelSU**临时root（越狱模式）使用！\n请勿在 Magisk / APatch 等环境下安装。"
fi

ui_print "→ KernelSU v$KSU_VER ($KSU_VER_CODE) 检测通过"

echo ""
echo "热重启模块 1.5.6    是小白狐呀"
echo "后续使用请在模块页面点击左下按纽运行"
echo "本模块仅提供了一种免重启让模块加载的方式，不能保证成功。"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 释放、配置权限
echo "正在释放所需文件并配置权限"
unzip -o "$MODPATH/c1.zip" -d "/data/adb/rcqpz/" > /dev/null
chmod +x /data/adb/rcqpz/jz.sh
echo "释放1完成"

echo""
echo"正在加载配置2...."
echo"正在加载配置2...."
echo"正在加载配置2...."
echo"正在加载配置2...."

[ -f "$MODPATH/customize.d/00-verify-resources.sh" ] || abort "! Part '00-verify-resources.sh' not found"
. "$MODPATH/customize.d/00-verify-resources.sh"
[ -f "$MODPATH/customize.d/10-enforce-api-version.sh" ] || abort "! Part '10-enforce-api-version.sh' not found"
. "$MODPATH/customize.d/10-enforce-api-version.sh"
[ -f "$MODPATH/customize.d/11-enforce-arch.sh" ] || abort "! Part '11-enforce-arch.sh' not found"
. "$MODPATH/customize.d/11-enforce-arch.sh"
[ -f "$MODPATH/customize.d/20-enforce-magisk-version.sh" ] || abort "! Part '20-enforce-magisk-version.sh' not found"
. "$MODPATH/customize.d/20-enforce-magisk-version.sh"
[ -f "$MODPATH/customize.d/21-enforce-ksu-kernel.sh" ] || abort "! Part '21-enforce-ksu-kernel.sh' not found"
. "$MODPATH/customize.d/21-enforce-ksu-kernel.sh"
[ -f "$MODPATH/customize.d/22-check-zygisk.sh" ] || abort "! Part '22-check-zygisk.sh' not found"
. "$MODPATH/customize.d/22-check-zygisk.sh"
[ -f "$MODPATH/customize.d/30-place-libraries.sh" ] || abort "! Part '30-place-libraries.sh' not found"
. "$MODPATH/customize.d/30-place-libraries.sh"
[ -f "$MODPATH/customize.d/35-install-manager-app.sh" ] || abort "! Part '35-install-manager-app.sh' not found"
. "$MODPATH/customize.d/35-install-manager-app.sh"
[ -f "$MODPATH/customize.d/90-restore-module-permission.sh" ] || abort "! Part '90-restore-module-permission.sh' not found"
. "$MODPATH/customize.d/90-restore-module-permission.sh"

rm -rf $MODPATH/customize.d

echo""
# 自动检测是否已安装模块
MODULE_PATH="/data/adb"
if [ -d "$MODULE_PATH" ]; then
    ui_print "— 验证通过...检测到KSU环境 → 3秒后执行重载"
    # 5秒倒计时提示
    for i in 3 2 1; do
        ui_print "→ $i 秒后开始重载..."
        sleep 1
    done
    /data/adb/rcqpz/jz.sh
    rm -rf /data/adb/rcqpz
else
    ui_print "— 未检测到模块目录 → 跳过重载，首次安装失败"
fi


