const navItems = document.querySelectorAll('.nav-item');
navItems.forEach(item => {
    item.addEventListener('click', function() {
        const tab = this.dataset.tab;
        if (tab === 'home') {
            window.location.replace('index.html');
        }
    });
});

const GAME_LIST = [
    { name: '和平精英', pkg: 'com.tencent.tmgp.pubgmhd' },
    { name: '三角洲', pkg: 'com.tencent.tmgp.dfm' },
    { name: '无畏契约', pkg: 'com.tencent.tmgp.codev' },
    { name: '王者荣耀', pkg: 'com.tencent.tmgp.sgame' },
    { name: '暗区突围', pkg: 'com.tencent.mf.uam' }
];

const DOWNLOAD_LIST = [
    {
        name: 'Zygisk Next',
        version: '1.4.2',
        type: 'module',
        url: 'https://zip1.webgetstore.com/2026/06/29/ea0b86633a95ba8ab4ae27fc7b4face4.zip?sg=5e3af589f38820ec6b10b43b9a7b0bf4&e=6a4190b0&fileName=Zygisk-Next-1.4.2-789-119aaa0-relea.zip&fi=293090263'
    },
    {
        name: 'ZN-Audit Patch',
        version: '1.2',
        type: 'module',
        url: 'https://zip1.webgetstore.com/2026/06/29/5da4df7b64d934d8de8be6d90a07a704.zip?sg=cdeb7747a3b34fec93265f995c526f09&e=6a419111&fileName=ZN-Audit-Patch-v1.2.0..zip&fi=293090266'
    },
    {
        name: 'LSPosed',
        version: '2.1.0',
        type: 'module',
        url: 'https://zip1.webgetstore.com/2026/06/29/2dbb6d0099947d19560efcff9b91a1c4.zip?sg=9869e270eb22b4087ad8bfedf155dafd&e=6a4190ec&fileName=LSPosed-v2.1.0-7769-release.zip&fi=293090264'
    },
    {
        name: 'HMA配置文件',
        version: '1',
        type: 'config',
        url: 'https://raw.githubusercontent.com/baihuya/m_rcq_rgx/refs/heads/main/bin/HMA.baihu.json'
    }
];

const RKP_FIX_URL = 'https://raw.githubusercontent.com/baihuya/m_rcq_rgx/refs/heads/main/bin/一键激活RKP为正常状态.sh';

let currentModal = null;

function closeModal() {
    if (currentModal) {
        currentModal.remove();
        currentModal = null;
    }
}

function createModal(contentHtml) {
    closeModal();
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop show';
    backdrop.innerHTML = `
        <div class="modal-box sub-modal-box">
            ${contentHtml}
        </div>
    `;
    backdrop.addEventListener('click', e => {
        if (e.target === backdrop) closeModal();
    });
    document.body.appendChild(backdrop);
    currentModal = backdrop;
    return backdrop;
}

function showResult(success, title, desc) {
    const iconClass = success ? 'fa-check text-ksuGreen' : 'fa-times text-ksuRed';
    const bgClass = success ? 'bg-ksuGreen/10' : 'bg-ksuRed/10';
    createModal(`
        <div class="flex flex-col items-center text-center">
            <div class="w-16 h-16 rounded-full flex items-center justify-center mb-4 ${bgClass}">
                <i class="fa ${iconClass} text-2xl"></i>
            </div>
            <h3 class="text-lg font-semibold text-ksuTextMain mb-2">${title}</h3>
            <p class="text-sm text-ksuTextSub mb-6">${desc}</p>
            <button class="w-full py-3.5 bg-ksuBlue text-white rounded-xl font-semibold text-base active:opacity-90" onclick="closeModal()">
                确定
            </button>
        </div>
    `);
}

function openDownloadMenu() {
    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">加载中...</p>
        </div>
    `);
    setTimeout(() => {
        let listHtml = '<h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">模块与资源下载</h3><div class="space-y-3">';
        DOWNLOAD_LIST.forEach((item, index) => {
            listHtml += `
                <div class="flex items-center gap-3 p-3 rounded-xl bg-[#F8F8FC]">
                    <div class="flex-1 min-w-0">
                        <div class="font-semibold text-sm text-ksuTextMain truncate">${item.name}</div>
                        <div class="text-[11px] text-ksuTextSub mt-0.5">版本 ${item.version}</div>
                    </div>
                    <button class="px-3 py-1.5 rounded-full bg-ksuBlue text-white text-xs font-medium active:opacity-80" onclick="startDownload(${index})">
                        下载安装
                    </button>
                </div>
            `;
        });
        listHtml += '</div><button class="btn-secondary mt-4" onclick="closeModal()">关闭</button>';
        createModal(listHtml);
    }, 800);
}

function startDownload(index) {
    const item = DOWNLOAD_LIST[index];
    const tempPath = `/data/local/tmp/${item.name.replace(/\s/g, '_')}`;
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">正在下载</h3>
        <p class="text-sm text-ksuTextMain mb-2 text-center">${item.name}</p>
        <div class="w-full h-2 rounded-full bg-[#E5E5EA] mb-2 overflow-hidden">
            <div id="progressBar" class="h-full bg-ksuBlue rounded-full transition-all duration-200" style="width: 0%"></div>
        </div>
        <p id="progressText" class="text-xs text-ksuTextSub text-center mb-4">0%</p>
    `);
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const xhr = new XMLHttpRequest();
    xhr.open('GET', item.url, true);
    xhr.responseType = 'blob';
    xhr.onprogress = function(e) {
        if (e.lengthComputable) {
            const progress = Math.round((e.loaded / e.total) * 100);
            progressBar.style.width = progress + '%';
            progressText.textContent = progress + '%';
        }
    };
    xhr.onload = async function() {
        progressBar.style.width = '100%';
        progressText.textContent = '下载完成，处理文件中...';
        if (xhr.status !== 200) {
            showResult(false, '下载失败', `请求异常，状态码：${xhr.status}`);
            return;
        }
        try {
            const blob = xhr.response;
            const arrayBuffer = await blob.arrayBuffer();
            const bytes = new Uint8Array(arrayBuffer);
            const binStr = Array.from(bytes).map(b => String.fromCharCode(b)).join('');
            const base64 = btoa(binStr);
            await ksu.exec(`echo '${base64}' | base64 -d > ${tempPath}`);
            if(item.type === 'module'){
                const installRes = await ksu.exec(`ksud module install ${tempPath}`);
                ksu.exec(`rm -f ${tempPath}`);
                if(installRes.errno === 0){
                    showResult(true, `${item.name} 安装完成`, "模块已安装，重启设备生效");
                }else{
                    showResult(false, "模块安装失败", installRes.stderr || "未知错误");
                }
            }else if(item.type === 'config'){
                await ksu.exec(`cp ${tempPath} /data/user/0/org.frknkrc44.hma_oss/files/config.json`);
                await ksu.exec(`chmod 755 /data/user/0/org.frknkrc44.hma_oss/files/config.json`);
                ksu.exec(`rm -f ${tempPath}`);
                showResult(true, "HMA配置写入完成", "配置文件已替换，重启HMA生效");
            }
        } catch (err) {
            ksu.exec(`rm -f ${tempPath}`);
            showResult(false, "处理失败", err.message || "权限不足");
        }
    };
    xhr.onerror = function() {
        showResult(false, '下载失败', '网络连接失败，建议切换网络或挂载代理');
    };
    xhr.send();
}

function fixRkpRed() {
    const tempPath = '/data/local/tmp/rkp_fix_tool';
    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">正在下载修复文件...</p>
        </div>
    `);

    const xhr = new XMLHttpRequest();
    xhr.open('GET', RKP_FIX_URL, true);
    xhr.responseType = 'blob';

    xhr.onload = async function() {
        if (xhr.status !== 200) {
            showResult(false, '下载失败', `修复文件下载失败，状态码：${xhr.status}`);
            return;
        }
        try {
            const blob = xhr.response;
            const arrayBuffer = await blob.arrayBuffer();
            const bytes = new Uint8Array(arrayBuffer);
            const binStr = Array.from(bytes).map(b => String.fromCharCode(b)).join('');
            const base64 = btoa(binStr);
            await ksu.exec(`echo '${base64}' | base64 -d > ${tempPath}`);
            await ksu.exec(`chmod 755 ${tempPath}`);

            const statusText = document.querySelector('.modal-box p');
            if (statusText) statusText.textContent = '正在执行修复...';

            const execRes = await ksu.exec(`sh ${tempPath}`);
            if (execRes.errno === 0) {
                showResult(true, '修复指令已下发', 'RKP修复操作已执行');
                setTimeout(() => ksu.exec(`rm -f ${tempPath}`), 30000);
            } else {
                showDownloadResult(false, '修复指令已下发', 'RKP修复操作已执行，请稍等......');
                ksu.exec(`rm -f ${tempPath}`);
            }
        } catch (e) {
            showResult(false, '可能是模块报错？', e.message || '文件写入异常');
            ksu.exec(`rm -f ${tempPath}`);
        }
    };

    xhr.onerror = function() {
        showResult(false, '下载失败', '网络连接异常，请检查网络后重试');
    };

    xhr.send();
}

function openRecWipeNotice() {
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">风险提示</h3>
        <p class="text-sm text-ksuTextSub mb-6 text-center leading-relaxed">
            此操作会重置应用权限<br>并刷新设备标识<br><br>其他应用可能需要<br>重新打开才能正常使用
        </p>
        <button class="w-full py-3 bg-ksuRed text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); openRecWipeMenu()">
            确定执行
        </button>
        <button class="btn-secondary" onclick="closeModal()">取消</button>
    `);
}

function openRecWipeMenu() {
    let listHtml = '<h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">选择游戏</h3><div class="space-y-2">';
    GAME_LIST.forEach((game, index) => {
        listHtml += `
            <button class="w-full py-3 bg-[#F8F8FC] rounded-xl text-sm font-medium text-ksuTextMain active:bg-[#EFEFF4] transition" onclick="closeModal(); showRecCloneMenu(${index})">
                ${game.name}
            </button>
        `;
    });
    listHtml += '</div><button class="btn-secondary mt-4" onclick="closeModal()">返回</button>';
    createModal(listHtml);
}

function showRecCloneMenu(index) {
    const game = GAME_LIST[index];
    createModal(`
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">${game.name}</h3>
        <button class="w-full py-3 bg-ksuBlue text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); executeRecWipe(${index}, false)">
            主应用
        </button>
        <button class="w-full py-3 bg-ksuBlue text-white rounded-xl font-semibold text-sm mb-3 active:opacity-90" onclick="closeModal(); executeRecWipe(${index}, true)">
            分身应用
        </button>
        <button class="btn-secondary" onclick="closeModal()">返回</button>
    `);
}

async function executeRecWipe(index, isClone) {
    const game = GAME_LIST[index];
    const pkg = game.pkg;
    const name = game.name;
    const dataBase = isClone ? `/data/user/999/${pkg}` : `/data/data/${pkg}`;

    createModal(`
        <div class="flex flex-col items-center gap-3 py-4">
            <div class="spinner"></div>
            <p class="text-ksuTextSub text-sm">正在执行双清...</p>
        </div>
    `);

    let steps;
    if (isClone) {
        steps = [
            `am force-stop ${pkg} 2>/dev/null`,
            `rm -rf /data/user/999/${pkg}/* /data/user/999/${pkg}/.* 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg}.xml 2>/dev/null`,
            `rm -rf ${dataBase}/files/ano_tmp 2>/dev/null`,
            `rm -rf /data/system/users/0/android_id.xml 2>/dev/null`,
            `rm -rf /data/system/advertising_id 2>/dev/null`,
            `rm -rf /data/system/oaid 2>/dev/null`,
            `rm -rf /sdcard/Android/data/${pkg} 2>/dev/null`,
            `rm -rf /sdcard/Android/obb/${pkg} 2>/dev/null`,
            `pm reset-permissions ${pkg} 2>/dev/null`,
            `pm revoke ${pkg} android.permission.READ_PHONE_STATE 2>/dev/null`,
            `pm revoke ${pkg} android.permission.QUERY_ALL_PACKAGES 2>/dev/null`
        ].join(" && ");
    } else {
        steps = [
            `am force-stop ${pkg} 2>/dev/null`,
            `pm clear ${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg} 2>/dev/null`,
            `rm -rf /data/system/users/0/settings_ssaid/${pkg}.xml 2>/dev/null`,
            `rm -rf ${dataBase}/files/ano_tmp 2>/dev/null`,
            `rm -rf /data/system/users/0/android_id.xml 2>/dev/null`,
            `rm -rf /data/system/advertising_id 2>/dev/null`,
            `rm -rf /data/system/oaid 2>/dev/null`,
            `rm -rf /sdcard/Android/data/${pkg} 2>/dev/null`,
            `rm -rf /sdcard/Android/obb/${pkg} 2>/dev/null`,
            `pm reset-permissions ${pkg} 2>/dev/null`,
            `pm revoke ${pkg} android.permission.READ_PHONE_STATE 2>/dev/null`,
            `pm revoke ${pkg} android.permission.QUERY_ALL_PACKAGES 2>/dev/null`
        ].join(" && ");
    }

    try {
        await ksu.exec(steps);
        setTimeout(() => {
            const label = isClone ? `${name}（分身）` : `${name}（主应用）`;
            showResult(true, '双清完成', `${label} 数据、标识、权限已全部重置`);
        }, 800);
    } catch (e) {
        showResult(false, '执行失败', e.message || '权限不足或应用不存在');
    }
}
// ========== 终端模拟器 ==========

function openTerminal() {
    // 仅弹出提示弹窗，不加载终端
    createModal(`
        <div class="py-6 text-center px-2">
            <h3 class="text-lg font-semibold text-ksuTextMain mb-4">功能开发中</h3>
            <p class="text-sm text-gray-500 mb-6">正在重构升级，敬请期待！</p>
            <button class="btn-secondary w-full" onclick="closeModal()">确定</button>
        </div>
    `);
}


function openHideFolder() {
    // 仅弹出提示弹窗，不加载终端
    createModal(`
        <div class="py-6 text-center px-2">
            <h3 class="text-lg font-semibold text-ksuTextMain mb-4">功能开发中</h3>
            <p class="text-sm text-gray-500 mb-6">正在重构升级，敬请期待！</p>
            <button class="btn-secondary w-full" onclick="closeModal()">确定</button>
        </div>
    `);
}

// 挂载到全局
window.openDownloadMenu = openDownloadMenu;
window.startDownload = startDownload;
window.closeModal = closeModal;
window.fixRkpRed = fixRkpRed;
window.openRecWipeNotice = openRecWipeNotice;
window.openRecWipeMenu = openRecWipeMenu;
window.showRecCloneMenu = showRecCloneMenu;
window.executeRecWipe = executeRecWipe;
window.openTerminal = openTerminal;
window.openHideFolder = openHideFolder;