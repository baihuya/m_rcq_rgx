const navItems = document.querySelectorAll('.nav-item');
const currentPath = window.location.pathname.split('/').pop() || 'index.html';

navItems.forEach(item => {
    const tab = item.dataset.tab;
    if (tab === 'home' && currentPath === 'index.html') {
        item.classList.add('active');
    }
    item.addEventListener('click', function() {
        if (tab === 'module') {
            window.location.replace('function.html');
        }
    });
});

const loadingMask = document.getElementById('loadingMask');
const loadingText = document.getElementById('loadingText');
function showLoading(text) {
    loadingText.textContent = text || '正在执行…';
    loadingMask.classList.add('show');
}
function hideLoading() {
    loadingMask.classList.remove('show');
}

const resultModal = document.getElementById('resultModal');
const resultIcon = document.getElementById('resultIcon');
const resultTitle = document.getElementById('resultTitle');
const resultDesc = document.getElementById('resultDesc');

function showResult(success, title, desc) {
    const icon = resultIcon.querySelector('i');
    if (success) {
        resultIcon.className = 'w-16 h-16 rounded-full flex items-center justify-center mb-4 bg-ksuGreen/10';
        icon.className = 'fa fa-check text-ksuGreen text-2xl';
    } else {
        resultIcon.className = 'w-16 h-16 rounded-full flex items-center justify-center mb-4 bg-ksuRed/10';
        icon.className = 'fa fa-times text-ksuRed text-2xl';
    }
    resultTitle.textContent = title || (success ? '执行成功' : '执行失败');
    resultDesc.textContent = desc || (success ? '操作已完成' : '操作未能完成');
    resultModal.classList.add('show');
}

function closeResultModal() {
    resultModal.classList.remove('show');
}
resultModal.addEventListener('click', function(e) {
    if (e.target === this) closeResultModal();
});

function showSubModal(title, contentHtml) {
    closeSubModal();
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop show';
    backdrop.style.position = 'fixed';
    backdrop.style.inset = '0';
    backdrop.style.zIndex = '55';
    backdrop.style.display = 'flex';
    backdrop.style.alignItems = 'center';
    backdrop.style.justifyContent = 'center';
    backdrop.style.padding = '20px';
    backdrop.style.background = 'rgba(0,0,0,0.35)';
    backdrop.style.backdropFilter = 'blur(6px)';
    backdrop.style.webkitBackdropFilter = 'blur(6px)';
    const box = document.createElement('div');
    box.className = 'modal-box sub-modal-box';
    box.style.maxWidth = '380px';
    box.style.width = '100%';
    box.style.padding = '28px 24px 24px';
    box.innerHTML = `
        <h3 class="text-lg font-semibold text-ksuTextMain mb-4 text-center">${title}</h3>
        <div>${contentHtml}</div>
    `;
    backdrop.appendChild(box);
    document.body.appendChild(backdrop);
    backdrop.addEventListener('click', function(e) {
        if (e.target === this) closeSubModal();
    });
    window._subModalRef = backdrop;
}

function closeSubModal() {
    if (window._subModalRef) {
        window._subModalRef.remove();
        window._subModalRef = null;
    }
}

async function showHelpInfo() {
    showLoading('正在获取说明…');
    try {
        const resp = await fetch('https://raw.githubusercontent.com/baihuya/m_rcq_rgx/refs/heads/main/bin/说明.txt');
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const text = await resp.text();
        hideLoading();
        const icon = resultIcon.querySelector('i');
        resultIcon.className = 'w-16 h-16 rounded-full flex items-center justify-center mb-4 bg-ksuBlue/10';
        icon.className = 'fa fa-info-circle text-ksuBlue text-2xl';
        resultTitle.textContent = '使用说明';
        resultDesc.textContent = text;
        resultModal.classList.add('show');
    } catch (e) {
        hideLoading();
        showResult(false, '获取失败', '无法加载云端说明\n' + e.message + '\n请尝试挂 VPN 后重试');
    }
}

async function showChangelog() {
    showLoading('正在获取日志…');
    try {
        const resp = await fetch('https://raw.githubusercontent.com/baihuya/m_rcq_rgx/refs/heads/main/bin/日志.txt');
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const text = await resp.text();
        hideLoading();
        const icon = resultIcon.querySelector('i');
        resultIcon.className = 'w-16 h-16 rounded-full flex items-center justify-center mb-4 bg-ksuBlue/10';
        icon.className = 'fa fa-file-text-o text-ksuBlue text-2xl';
        resultTitle.textContent = '更新日志';
        resultDesc.textContent = text;
        resultModal.classList.add('show');
    } catch (e) {
        hideLoading();
        showResult(false, '获取失败', '无法加载更新日志\n' + e.message);
    }
}

async function execHotReboot() {
    showLoading('正在执行热重启…');
    await sleep(800);
    try {
        const script = '/data/adb/modules/m_rcq/bin/rcq.sh';
        const result = await ksu.exec('sh ' + script);
        hideLoading();
        if (result.errno === 0) {
            const log = result.stdout || '小白狐呀…\n热重启中…\nDone. Restarting zygote…';
            showResult(true, '热重启已发送', log);
        } else {
            showResult(false, '执行失败', '错误码: ' + result.errno + '\n' + (result.stderr || ''));
        }
    } catch (e) {
        hideLoading();
        showResult(false, '调用异常', e.message || '无法执行脚本，请检查模块路径与权限');
    }
}

async function execLoadModules() {
    showLoading('正在加载全部模块…');
    await sleep(800);
    try {
        const script = '/data/adb/modules/m_rcq/bin/jz.sh';
        const result = await ksu.exec('sh ' + script);
        hideLoading();
        if (result.errno === 0) {
            showResult(true, '加载完成', result.stdout || '所有已启用模块已重新挂载');
        } else {
            showResult(false, '执行失败', '错误码: ' + result.errno + '\n' + (result.stderr || ''));
        }
    } catch (e) {
        hideLoading();
        showResult(false, '调用异常', e.message || '无法执行脚本，请检查模块路径与权限');
    }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

const GAME_LIST = [
    { name: '和平精英', pkg: 'com.tencent.tmgp.pubgmhd', path: '/data/data/com.tencent.tmgp.pubgmhd/files/ano_tmp' },
    { name: '三角洲', pkg: 'com.tencent.tmgp.dfm', path: '/data/data/com.tencent.tmgp.dfm/files/ano_tmp' },
    { name: '无畏契约', pkg: 'com.tencent.tmgp.codev', path: '/data/data/com.tencent.tmgp.codev/files/ano_tmp' },
    { name: '王者荣耀', pkg: 'com.tencent.tmgp.sgame', path: '/data/data/com.tencent.tmgp.sgame/files/ano_tmp' },
    { name: '暗区突围', pkg: 'com.tencent.mf.uam', path: '/data/data/com.tencent.mf.uam/files/ano_tmp' }
];

function openGameCleanMenu() {
    let html = GAME_LIST.map((g, i) =>
        `<button class="game-btn" data-index="${i}">${g.name}</button>`
    ).join('');
    html += `<button class="game-btn" style="background:#E5E5EA;color:#8E8E93;margin-top:6px;" id="cleanBack">返回</button>`;
    showSubModal('选择游戏', html);
    document.querySelectorAll('[data-index]').forEach(btn => {
        btn.onclick = function() {
            const idx = parseInt(this.dataset.index);
            closeSubModal();
            showAppTypeMenu(GAME_LIST[idx]);
        };
    });
    document.getElementById('cleanBack').onclick = closeSubModal;
}

function showAppTypeMenu(game) {
    const html = `
        <button class="game-btn" id="mainApp">主应用</button>
        <button class="game-btn" id="cloneApp">分身应用</button>
        <button class="game-btn" style="background:#E5E5EA;color:#8E8E93;margin-top:6px;" id="backBtn">返回</button>
    `;
    showSubModal(game.name, html);
    document.getElementById('mainApp').onclick = function() {
        closeSubModal();
        runClean(game.pkg, game.name + ' (主应用)', game.path, false);
    };
    document.getElementById('cloneApp').onclick = function() {
        closeSubModal();
        const clonePath = game.path.replace('/data/data/', '/data/user/999/');
        runClean(game.pkg, game.name + ' (分身)', clonePath, true);
    };
    document.getElementById('backBtn').onclick = closeSubModal;
}

function runClean(pkg, name, path, isClone) {
    showLoading('正在清理…');
    setTimeout(async () => {
        try {
            await ksu.exec('rm -rf ' + path + ' 2>/dev/null');
            if (isClone) {
                const clonePath2 = path.replace('/data/user/999/', '/data/user/999_de/');
                await ksu.exec('rm -rf ' + clonePath2 + ' 2>/dev/null');
            } else {
                const mainPath = path.replace('/data/data/', '/data/user/0/');
                await ksu.exec('rm -rf ' + mainPath + ' 2>/dev/null');
            }
            const base = isClone ? '/data/user/999/' + pkg : '/data/data/' + pkg;
            const cmd = [
                'am force-stop ' + pkg,
                'rm -f ' + base + '/shared_prefs/*login*.xml',
                'rm -f ' + base + '/shared_prefs/*account*.xml',
                'rm -f ' + base + '/shared_prefs/*auth*.xml',
                'rm -f ' + base + '/shared_prefs/*msdk*.xml',
                'rm -f ' + base + '/shared_prefs/*openid*.xml',
                'rm -f ' + base + '/shared_prefs/*token*.xml',
                'rm -rf ' + base + '/files/*login*',
                'rm -rf ' + base + '/files/*token*',
                'rm -rf ' + base + '/files/*session*',
                'rm -f ' + base + '/databases/*login*',
                'rm -f ' + base + '/databases/*account*'
            ].join(' && ');
            await ksu.exec(cmd);
            hideLoading();
            showResult(true, '清理完成', name + ' 日志与登录凭证已清理');
        } catch (e) {
            hideLoading();
            showResult(false, '清理失败', '未找到对应游戏或无执行权限');
        }
    }, 400);
}

function openCrashMenu() {
    const html = `
        <div class="text-sm text-ksuTextSub mb-4 text-center leading-relaxed">
            宽容模式进入游戏，<br>大厅切强制模式
        </div>
        <button class="game-btn" id="crashOn">🛡️ 宽容模式</button>
        <button class="game-btn" id="crashOff">⚡ 强制模式</button>
        <button class="game-btn" style="background:#E5E5EA;color:#8E8E93;margin-top:6px;" id="crashBack">返回</button>
    `;
    showSubModal('王者荣耀闪退修复', html);
    document.getElementById('crashOn').onclick = function() {
        fixWzryCrash(true);
        closeSubModal();
        showResult(true, '操作完成', '已切换为宽容模式\n请重新进入王者荣耀');
    };
    document.getElementById('crashOff').onclick = function() {
        fixWzryCrash(false);
        closeSubModal();
        showResult(true, '操作完成', '已切换为强制模式');
    };
    document.getElementById('crashBack').onclick = closeSubModal;
}

function fixWzryCrash(permissive) {
    if (!window.ksu) return;
    ksu.exec('am force-stop com.tencent.tmgp.sgame');
    if (permissive) {
        ksu.exec('setenforce 0');
    } else {
        ksu.exec('setenforce 1');
    }
}

async function autoFixEnv() {
    try {
        const cmds = [
            'chmod 755 /data/adb/modules/m_rcq/service.sh',
            'chmod 755 /data/adb/modules/m_rcq/bin/jz.sh',
            'chmod 755 /data/adb/modules/m_rcq/bin/rcq.sh',
            'chmod 755 /data/adb/modules/m_rcq/webroot/index.html',
            'chmod 755 /data/adb/modules/m_rcq/webroot/function.js',
            'chmod 755 /data/adb/modules/m_rcq/webroot/function.html',
            'chmod 755 /data/adb/modules/m_rcq/webroot/main.js',
            'chmod 755 /data/adb/modules/m_rcq/webroot/style.css',
            'rm -rf /data/adb/rcqpz',
            'rm -rf /data/adb/modules/m_rcq/c1.zip',
            'rm -rf /data/adb/modules/m_rcq/customize.sh',
            'rm -f /data/adb/modules/m_rcq/_mgr_tmp.apk'
        ];
        for (const cmd of cmds) {
            await ksu.exec(cmd);
        }
    } catch (_) {}
}

document.addEventListener('DOMContentLoaded', function() {
    autoFixEnv();
    resultModal.classList.remove('show');
});

window.showHelpInfo = showHelpInfo;
window.showChangelog = showChangelog;
window.execHotReboot = execHotReboot;
window.execLoadModules = execLoadModules;
window.openGameCleanMenu = openGameCleanMenu;
window.openCrashMenu = openCrashMenu;
window.closeResultModal = closeResultModal;
window.closeSubModal = closeSubModal;
