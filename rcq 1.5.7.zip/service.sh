#!/system/bin/sh
check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -z "$VALUE" ] || [ "$VALUE" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

contains_reset_prop() {
  local NAME="$1"
  local CONTAINS="$2"
  local NEWVAL="$3"
  [[ "$(resetprop "$NAME" 2>/dev/null)" = *"$CONTAINS"* ]] && resetprop -n "$NAME" "$NEWVAL"
}

echo 2 > /proc/sys/kernel/kptr_restrict
echo 1 > /proc/sys/kernel/dmesg_restrict
echo 0 > /proc/sys/fs/suid_dumpable
echo 0 > /proc/sys/kernel/core_pattern
echo 2 > /proc/sys/kernel/perf_event_paranoid
restorecon /dev/__properties__/u:object_r:adbd_config_prop:s0 2>/dev/null
restorecon /dev/__properties__/u:object_r:shell_prop:s0 2>/dev/null

chmod 777 /data/adb/modules/m_rcq/I_am_taffy
/data/adb/modules/m_rcq/I_am_taffy

resetprop -w sys.boot_completed 0

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"
check_reset_prop "sys.oem_unlock_allowed" "0"

check_reset_prop "vendor.boot.flash.locked" "1"
check_reset_prop "vendor.boot.veritymode" "enforcing"
check_reset_prop "ro.vendor.boot.flash.locked" "1"
check_reset_prop "ro.vendor.boot.veritymode" "enforcing"
check_reset_prop "vendor.secureboot.lockstate" "locked"
check_reset_prop "vendor.boot.secureboot" "1"

check_reset_prop "odm.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.odm.boot.vbmeta.device_state" "locked"
check_reset_prop "odm.boot.verifiedbootstate" "green"

check_reset_prop "ro.oem_unlock_supported" "0"
check_reset_prop "ro.boot.oem_unlock_supported" "0"
check_reset_prop "ro.boot.oem_unlock" "0"
check_reset_prop "persist.oem.unlock_state" "0"
check_reset_prop "persist.sys.oem.unlocked" "0"

check_reset_prop "ro.secureboot.enabled" "1"
check_reset_prop "ro.boot.vbmeta.bootloader_state" "locked"
check_reset_prop "ro.boot.secboot.enabled" "1"
check_reset_prop "ro.boot.frp.lock" "1"
check_reset_prop "ro.vendor.boot.secureboot" "1"
check_reset_prop "persist.sys.secboot.state" "1"
check_reset_prop "ro.boot.vbmeta.rollback_index" "0"
check_reset_prop "ro.boot.vbmeta.device_locked" "1"

check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"

check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

check_reset_prop "ro.boot.bootloader" "locked"
check_reset_prop "ro.boot.locked" "1"
check_reset_prop "ro.build.bootloader" "locked"

check_reset_prop "ro.boot.avb_version" "1.0"
check_reset_prop "ro.boot.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_version" "1.0"
check_reset_prop "ro.boot.vbmeta.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_status" "ok"
check_reset_prop "ro.boot.vbmeta.status" "ok"

check_reset_prop "ro.tee.status" "ok"
check_reset_prop "vendor.tee.status" "ok"
check_reset_prop "sys.tee.ready" "1"
check_reset_prop "persist.tee.ready" "1"

check_reset_prop "ro.soter.available" "1"
check_reset_prop "persist.soter.available" "1"
check_reset_prop "vendor.soter.available" "1"
check_reset_prop "ro.soter.supported" "1"
check_reset_prop "persist.soter.supported" "1"

check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"

contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

setenforce 1
resetprop -w sys.boot_completed 1

HIDE_PROCS="magisk magiskd su ksu ksud kernelsu ksuhelper"

for proc_name in $HIDE_PROCS; do
    for pid in $(pidof "$proc_name" 2>/dev/null); do
        chmod 000 "/proc/$pid" 2>/dev/null
        if [ -d "/proc/$pid/task" ]; then
            for tid in /proc/$pid/task/*; do
                chmod 000 "$tid" 2>/dev/null
            done
        fi
    done
done

chmod 000 /proc/ksu 2>/dev/null
chmod 000 /proc/kallsyms 2>/dev/null
chmod 000 /proc/modules 2>/dev/null
chmod 000 /sys/kernel/debug 2>/dev/null
chmod 000 /sys/kernel/debug/tracing 2>/dev/null

echo 1 > /proc/sys/kernel/randomize_va_space
echo 0 > /proc/sys/vm/oom_dump_tasks 2>/dev/null
