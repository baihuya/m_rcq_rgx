#!/system/bin/sh
check_reset_prop() {
  local NAME="$1"
  local EXPECTED="$2"
  local VALUE=$(resetprop "$NAME" 2>/dev/null)
  [ -z "$VALUE" ] || [ "$VALUE" = "$EXPECTED" ] || resetprop -n "$NAME" "$EXPECTED"
}

contains_reset_prop() {
  local NAME="$1"
  local CONTAINS="$2"
  local NEWVAL="$3"
  [[ "$(resetprop "$NAME" 2>/dev/null)" = *"$CONTAINS"* ]] && resetprop -n "$NAME" "$NEWVAL"
}

echo 0 > /proc/sys/kernel/kptr_restrict
echo 0 > /proc/sys/kernel/dmesg_restrict
echo 0 > /proc/sys/fs/suid_dumpable
echo 0 > /proc/sys/kernel/core_pattern
restorecon /dev/__properties__/u:object_r:adbd_config_prop:s0 2>/dev/null
restorecon /dev/__properties__/u:object_r:shell_prop:s0 2>/dev/null
resetprop -w sys.boot_completed 0

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "ro.secureboot.lockstate" "locked"
check_reset_prop "ro.boot.secureboot" "1"
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"
check_reset_prop "ro.boot.bootloader" "locked"
check_reset_prop "ro.boot.locked" "1"
check_reset_prop "ro.build.bootloader" "locked"
check_reset_prop "ro.boot.avb_version" "1.0"
check_reset_prop "ro.boot.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_version" "1.0"
check_reset_prop "ro.boot.vbmeta.avb_state" "ok"
check_reset_prop "ro.boot.vbmeta.avb_status" "ok"
check_reset_prop "ro.boot.vbmeta.status" "ok"

check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "persist.sys.root_access" "0"
check_reset_prop "ro.crypto.state" "encrypted"
check_reset_prop "ro.build.selinux" "1"
check_reset_prop "ro.config.low_ram" "false"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.boot.selinux" "enforcing"
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

check_reset_prop "ro.tee.status" "ok"
check_reset_prop "vendor.tee.status" "ok"
check_reset_prop "sys.tee.ready" "1"
check_reset_prop "persist.tee.ready" "1"

check_reset_prop "ro.soter.available" "1"
check_reset_prop "persist.soter.available" "1"
check_reset_prop "vendor.soter.available" "1"
check_reset_prop "ro.soter.supported" "1"
check_reset_prop "persist.soter.supported" "1"

setenforce 1
resetprop -w sys.boot_completed 1

# 白狐